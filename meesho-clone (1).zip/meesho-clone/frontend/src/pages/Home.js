import React from 'react';

const Home = () => {
  return <h1>Welcome to Meesho Clone</h1>;
};

export default Home;
